package com.example.roomservice.service;
import com.example.roomservice.client.RoomTypeClient;
import com.example.roomservice.entity.Room;
import com.example.roomservice.exception.InvalidRoomTypeException;
import com.example.roomservice.repository.RoomRepository;
import feign.FeignException;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {
    private final RoomRepository roomRepository;
    private final RoomTypeClient roomTypeClient;
    public RoomService(RoomRepository roomRepository, RoomTypeClient roomTypeClient) {
        this.roomRepository = roomRepository;
        this.roomTypeClient = roomTypeClient;
    }
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }
    public Room addRoom(Room room) {
        if (room.getRoomTypeId() == null || room.getRoomTypeId().isBlank()) {
            throw new InvalidRoomTypeException("roomTypeId must not be empty");
        }
        try {
            roomTypeClient.getRoomTypeById(room.getRoomTypeId());
        } catch (FeignException.NotFound e) {
            throw new InvalidRoomTypeException("Room type not found with id: " + room.getRoomTypeId());
        } catch (FeignException e) {
            throw new RuntimeException("Cannot reach roomtype-service: " + e.getMessage());
        }
        room.setId(null);
        return roomRepository.save(room);
    }
}
