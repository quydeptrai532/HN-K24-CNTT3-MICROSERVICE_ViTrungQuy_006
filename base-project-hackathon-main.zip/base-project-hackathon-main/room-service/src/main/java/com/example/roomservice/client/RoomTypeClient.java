package com.example.roomservice.client;
import com.example.roomservice.dto.RoomTypeDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "roomtype-service")
public interface RoomTypeClient {
    @GetMapping("/api/roomtypes/{id}")
    RoomTypeDto getRoomTypeById(@PathVariable("id") String id);
}
