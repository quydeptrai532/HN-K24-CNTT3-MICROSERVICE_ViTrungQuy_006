package com.example.roomservice.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomTypeDto {
    private String id;
    private String name;
    private String description;
    private String location;
    private double price;
}
