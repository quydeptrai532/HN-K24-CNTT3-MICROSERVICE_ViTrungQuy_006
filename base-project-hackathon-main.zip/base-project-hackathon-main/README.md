Thứ tự chạy

1. eureka-server
2. config-server
3. roomtype-service
4. room-service
5. api-gateway

API Kết quả
GET /api/roomtypes/RT01 200
POST /api/rooms với RT01 201 Created
POST /api/rooms với RT99 400 Bad Request
GET /api/rooms 200
