package com.example.roomtypeservice.service;
import com.example.roomtypeservice.entity.RoomType;
import com.example.roomtypeservice.repository.RoomTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class RoomTypeService {
    private final RoomTypeRepository roomTypeRepository;
    public RoomTypeService(RoomTypeRepository roomTypeRepository) {
        this.roomTypeRepository = roomTypeRepository;
    }
    public RoomType findRoomTypeById(String id) {
        return roomTypeRepository.findRoomTypeById(id);
    }
    public Iterable<RoomType> getAllRoomTypes() {
        return roomTypeRepository.findAll();
    }
}
