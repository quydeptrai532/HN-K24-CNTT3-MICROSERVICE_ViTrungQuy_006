package com.example.roomtypeservice.config;
import com.example.roomtypeservice.entity.RoomType;
import com.example.roomtypeservice.repository.RoomTypeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner initRoomTypes(RoomTypeRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new RoomType("RT01", "Standard", "Phong tieu chuan", "Tang 1", 500000));
                repository.save(new RoomType("RT02", "Deluxe", "Phong cao cap", "Tang 2", 900000));
                repository.save(new RoomType("RT03", "Suite", "Phong hang sang", "Tang 3", 1500000));
            }
        };
    }
}
