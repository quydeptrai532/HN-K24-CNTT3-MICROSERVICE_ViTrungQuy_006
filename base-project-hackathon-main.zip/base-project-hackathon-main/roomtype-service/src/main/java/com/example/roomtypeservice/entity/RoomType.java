package com.example.roomtypeservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RoomType {
    @Id
    private String id;
    private String name;
    private String description;
    private String location;
    private double price;
}
