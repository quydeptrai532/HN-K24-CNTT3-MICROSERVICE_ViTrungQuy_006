package com.example.roomtypeservice.repository;

import com.example.roomtypeservice.entity.RoomType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoomTypeRepository extends CrudRepository<RoomType, String> {
    RoomType findRoomTypeById(String id);
}
