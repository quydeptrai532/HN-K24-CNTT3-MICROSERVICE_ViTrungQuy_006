package com.example.roomtypeservice.controller;
import com.example.roomtypeservice.entity.RoomType;
import com.example.roomtypeservice.service.RoomTypeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/roomtypes")
public class RoomTypeController {
    private final RoomTypeService roomTypeService;
    public RoomTypeController(RoomTypeService roomTypeService) {
        this.roomTypeService = roomTypeService;
    }
    @GetMapping("/{id}")
    public ResponseEntity<RoomType> findById(@PathVariable String id) {
        RoomType result = roomTypeService.findRoomTypeById(id);
        if (result == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(result);
    }
    @GetMapping
    public ResponseEntity<Iterable<RoomType>> getAll() {
        return ResponseEntity.ok(roomTypeService.getAllRoomTypes());
    }
}
